# Lux AI Toolkit Club Free Sample

Version 1.0.1 — Business Starter sample

Start with Checklist.md. This archive contains five complete prompts, two editable CSV templates, a workflow, and a quick-start checklist. No sign-in or paid tool is required to edit these files.

## Use the sample
1. Copy one prompt from 5-AI-Prompts.txt into your chosen AI tool.
2. Replace every bracketed field. Use synthetic or approved non-sensitive details; do not paste passwords, customer records, or private account information.
3. Open Action-Plan.csv and Content-Calendar.csv in a spreadsheet or text editor. Replace the example rows and save your own copy.
4. Review generated text for unsupported claims, accuracy, and permission before using it.

The sample does not create an account, send messages, publish content, or grant member access. You control any action taken using the output.
