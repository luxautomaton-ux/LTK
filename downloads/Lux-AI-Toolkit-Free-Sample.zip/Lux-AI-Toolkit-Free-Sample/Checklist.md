# Quick Start
- Pick one business problem
- Use one prompt
- Review the output
- Remove unsupported claims
- Save the final version
