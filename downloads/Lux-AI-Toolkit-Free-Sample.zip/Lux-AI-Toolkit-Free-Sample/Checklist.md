# Quick-start checklist

- [ ] Pick one small business problem and write a measurable outcome.
- [ ] Open both CSV templates and save working copies.
- [ ] Choose one of the five prompts and replace every bracketed field.
- [ ] Remove private data and confirm permission to use the remaining context.
- [ ] Generate a draft; label uncertain statements and verify factual claims.
- [ ] Review with the owner and make any corrections.
- [ ] Save the reviewed artifact and update its status in Action-Plan.csv.
- [ ] Obtain separate approval before sending, publishing, purchasing, or changing an account.
- [ ] Record the result and one next improvement.
