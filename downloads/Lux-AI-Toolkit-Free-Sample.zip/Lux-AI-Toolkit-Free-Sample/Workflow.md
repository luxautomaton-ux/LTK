# One-page workflow: goal to reviewed draft

**Owner:** [name]  **Review date:** [date]

1. Define one outcome and how you will recognize completion in Action-Plan.csv.
2. Gather only approved, non-sensitive context. Stop if you lack permission to use it.
3. Choose a prompt, fill every bracket, and generate a draft with your chosen tool.
4. Compare the draft against your source facts. Remove invented claims and identify unresolved questions.
5. Have the owner approve the final copy. Sending, publishing, purchases, and account changes require their own approval.
6. Save the approved version and its date. If it is content, plan it in Content-Calendar.csv; scheduling a row does not publish it.
7. Record what worked and the next improvement. If a check fails, return to the draft and keep the last approved version.

**Done means:** a reviewed local artifact exists, its owner is recorded, and remaining actions are explicit. A generated draft alone is not completed delivery.
