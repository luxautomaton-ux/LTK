# Simple AI Workflow
1. Define the outcome.
2. Gather approved context.
3. Draft with AI.
4. Human review.
5. Publish or deliver.
6. Record what worked.
